#include<stdio.h>
#include<stdlib.h>
#include "lib_kwadrat.a"
#include "lib_szescian.so"

//int oblicz_kwadrat(int bok);


int main(int argc, char *argv[]) 
{
    int bok, pole;
    int objetosc;
    
    
    bok = atoi(argv[1]); //pobiera pierwszy argument z linii
   

    pole=oblicz_kwadrat(bok);
    objetosc=oblicz_szescian(bok);
    //licze pole kwadratu i objetosc szescianu
    //pole=bok*bok objetosc=bok*bok*bok

    printf("\nPole kwadratu wynosi: %d\n", pole);
    printf("Objetosc szescianu wynosi: %d\n", objetosc);
    //printf("\n");
   
    return (0);
}

