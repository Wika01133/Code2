int oblicz_kwadrat(int bok)
{
    int pole;

    pole = bok*bok;
    
    return (pole);
}
