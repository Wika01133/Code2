int oblicz_szescian(int bok)
{
    int objetosc;

    objetosc = bok*bok*bok;
    
    return (objetosc);
}
